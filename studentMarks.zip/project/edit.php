<!DOCTYPE html>
<html>

<head>
    <title>Edit Student</title>
</head>
<style>
    body{
        background-image: url(picture.WEBP);
        }
    </style>
<body>
    <center>
<?php
    $username = 'root';
    $password = '';
    $servername = 'localhost';
    $db_name = 'student';
    $connection = mysqli_connect($servername, $username, $password, $db_name);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $newName = $_POST["newName"];
        $newMarks = $_POST["newMarks"];
        
        $oldName = $_POST["oldName"];
        
        $query = "UPDATE studentdata SET name='$newName', marks='$newMarks' WHERE name='$oldName'";
        
        if (mysqli_query($connection, $query)) {
            echo "Record updated successfully.";
        } else {
            echo "Error updating record: " . mysqli_error($connection);
        }
    }
    
    $oldName = $_GET["name"];
    $query = "SELECT name, marks FROM studentdata WHERE name='$oldName'";
    $result = mysqli_query($connection, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        ?>
        <form method="post" id="editForm">
            <input type="text" name="newName" value="<?php echo $data['name']; ?>" placeholder="New Name"><br><br>
            <input type="number" name="newMarks" value="<?php echo $data['marks']; ?>" placeholder="New Marks"><br><br>
            <input type="hidden" name="oldName" value="<?php echo $data['name']; ?>">
            <input type="submit" value="Update">
        </form>
        <?php
    } else {
        echo "No records found";
    }
    mysqli_close($connection);
?>
    </center>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $('#editForm').validate({
                rules: {
                    newName: {
                        required: true
                    },
                    newMarks: {
                        required: true,
                        number: true
                    }
                },
                messages: {
                    newName: {
                        required: "Please enter the new name"
                    },
                    newMarks: {
                        required: "Please enter the new marks",
                        number: "Please enter a valid number for marks"
                    }
                }
            });
        });
    </script>
</html>
