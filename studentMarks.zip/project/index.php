<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Store data into database</title>
    <style type="text/css">
        input{
            margin-top: 20px;
        }
        body{
            background-image: url("picture.WEBP");
            padding: 50px;
            border-color: black;
            
        }
    </style>
</head>
<body>
    <center>
        <form action="storeData.php" method="post" style="margin-top: 50px;" class="validation-form">
    <input type="text" placeholder="Student name" id="std_name" name="std_name" ><br>
    <input type="number" name="marks" placeholder="Student Marks" id="marks"><br><br>

    <button>submit</button><br><br>
</form>
<a href="viewdata.php">View Records</a>
    </center>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
    <script type="text/javascript">
    $(document).ready(function() {
        $('.validation-form').validate({
            rules: {
                std_name: {
                    required: true
                },
                marks: {
                    required: true,
                    number: true
                }
            },
            messages: {
                std_name: {
                    required: "Please enter the student name"
                },
                marks: {
                    required: "Please enter the student's marks",
                    number: "Please enter a valid number for marks"
                }
            },
            submitHandler: function(form) {
               
                form.submit();
            }
        });
    });
</script>

</html>