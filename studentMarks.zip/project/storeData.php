<?php 
	$name = $_POST['std_name'];
	$marks = $_POST['marks'];
	$username = 'root';
    $password = '';
    $servername = 'localhost';
    $db_name = 'student';
    $connection = mysqli_connect($servername, $username, $password, $db_name);
	$query = "insert into studentdata (name, marks) values('$name','$marks')";
	if ($connection) {
		if ($connection->query($query)) {
			echo "Data inserted Successfully";
		}
		else
		{
			echo "Facing error. Please review you code or connection";
		}
	}
	else{
		echo "Somethings wents wrong";
	}
 ?>