<!DOCTYPE html>
<html>
<head>
    <title>____________Student Data___________</title>
    <style>
   body{
 background-image: url(picture.WEBP);
 padding: 50px;
   }
   table , td, tr{
  border : 2px solid black;
  border-radius: 2px;
  padding: 20px;
   }
   </style>
</head>
<body>
    
    <center>
<h2>____________Students Record__________</h2>
<?php
    $username = 'root';
    $password = '';
    $servername = 'localhost';
    $db_name = 'student';
    $connection = mysqli_connect($servername, $username, $password, $db_name);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT name, marks FROM studentdata";
    $result = mysqli_query($connection,$query);
?>

<table  border="1" cellspacing="0" cellpadding="10"  table-hover table-bordered table-striped>
  <tr>
    <th>Name</th>
    <th>Marks</th>
    <th>Delete</th>
    <th>Edit</th>
  </tr>

<?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($data = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $data['name'] . "</td>";
            echo "<td>" . $data['marks'] . "</td>";
            echo "<td><a href='delete.php?name=" . $data['name'] . "'>Delete</a></td>";
            echo "<td><a href='edit.php?name=" . $data['name'] . "'>Edit</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No records found</td></tr>";
    }

    mysqli_close($connection);
?>

</table>
    </center>
</body>
</html>
