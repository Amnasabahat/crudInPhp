<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "student";
$connection = mysqli_connect($servername, $username, $password, $db_name);
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
    $name = $_GET['name'];
    if($name!="")
    {
    $query = "DELETE FROM studentdata WHERE name = '$name' ";
}
    if (mysqli_query($connection, $query)) {
        echo "Record with Name $name has been deleted successfully.";
    } 
    else {
        echo "Error deleting record: " . mysqli_error($connection);
    }
mysqli_close($connection);
?>
